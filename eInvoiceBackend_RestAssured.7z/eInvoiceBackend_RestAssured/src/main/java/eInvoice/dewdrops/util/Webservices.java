package eInvoice.dewdrops.util;

import java.util.List;

import org.testng.Reporter;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Webservices {
	
	public static Response Post(String uRI, String payLoad_JSON,String header_tenantId) {
		RequestSpecification requestSpecification = RestAssured.given().body(payLoad_JSON);
		requestSpecification.contentType(ContentType.JSON);
		requestSpecification.header("x-zycus-tenantId", header_tenantId);
		
		
		Reporter.log("", true);
		Reporter.log("Web Service Info - >", true);
		Reporter.log("PayLoad :  - >" + payLoad_JSON, true);
		Reporter.log("Header TenantId :  - >" + header_tenantId, true);
		Response response = requestSpecification.post(uRI);
		Reporter.log("Response Body :  - >" + response.asString(), true);
		Reporter.log("", true);
		
		return response;

	}

	public static Response Get(String uRI,String header_tenantId) {
		RequestSpecification requestSpecification = RestAssured.given();
		requestSpecification.contentType(ContentType.JSON);
		
		
		Reporter.log("", true);
		Reporter.log("Web Service Info - >", true);
		Reporter.log("Header TenantId :  - >" + header_tenantId, true);
		Response response = requestSpecification.get(uRI);
		Reporter.log("Response Body :  - >" + response.asString(), true);
		Reporter.log("", true);
		
		return response;

	}

	public static Response Put(String uRI, String payLoad_JSON,String header_tenantId) {
		RequestSpecification requestSpecification = RestAssured.given().body(payLoad_JSON);
		requestSpecification.contentType(ContentType.JSON);
		
		Reporter.log("", true);
		Reporter.log("Web Service Info - >", true);
		Reporter.log("PayLoad :  - >" + payLoad_JSON, true);
		Reporter.log("Header TenantId :  - >" + header_tenantId, true);
		Response response = requestSpecification.put(uRI);
		Reporter.log("Response Body :  - >" + response.asString(), true);
		Reporter.log("", true);
		
		return response;

	}
	
	public static Response Delete(String uRI,String header_tenantId) {
		RequestSpecification requestSpecification = RestAssured.given();
		requestSpecification.contentType(ContentType.JSON);
		Response response = requestSpecification.delete(uRI);
		
		Reporter.log("", true);
		Reporter.log("Web Service Info - >", true);
		Reporter.log("Header TenantId :  - >" + header_tenantId, true);
		Reporter.log("Response Body :  - >" + response.asString(), true);
		Reporter.log("", true);
		
		return response;

	}
	
	public static Response POSTRequestWithHeader(String URI, String strJSON,List<Header> header) {
		RequestSpecification requestSpecification = RestAssured.given().body(strJSON);
		requestSpecification.contentType(ContentType.JSON);
		Headers he = new Headers(header);
		requestSpecification.headers(he);
		Response response = requestSpecification.post(URI);
		return response;
	}
	/***
	 * 
	 * @param URI
	 * @param strJSON
	 * @param Userid
	 * @param tenantId
	 * @param trackingNumber
	 * @return Response
	 */
	public static Response POSTRequestWithHeader(String URI, String strJSON,String Userid,String tenantId,int trackingNumber) {
		RequestSpecification requestSpecification = RestAssured.given().body(strJSON);
		requestSpecification.contentType(ContentType.JSON);
		requestSpecification.header("x-zycus-tenantId", tenantId);
		requestSpecification.header("x-zycus-userId", Userid);
		requestSpecification.header("x-zycus-trackingNumber", trackingNumber);
		Response response = requestSpecification.post(URI);
		return response;
	}
	/***
	 * 
	 * @param URI
	 * @param strJSON
	 * @param Userid
	 * @param tenantId
	 * @return Response
	 */
	
	public static Response POSTRequestWithHeader(String URI, String strJSON,String Userid,String tenantId) {
		RequestSpecification requestSpecification = RestAssured.given().body(strJSON);
		requestSpecification.contentType(ContentType.JSON);
		requestSpecification.header("x-zycus-tenantId", tenantId);
		requestSpecification.header("x-zycus-userId", Userid);
		Response response = requestSpecification.post(URI);
		return response;
	}
	/***
	 * 
	 * @param URI
	 * @param Userid
	 * @param tenantId
	 * @param trackingNumber
	 * @return Response
	 */
	public static Response GETRequestWithHeader(String URI,String Userid,String tenantId,int trackingNumber) {
		RequestSpecification requestSpecification = RestAssured.given();
		requestSpecification.contentType(ContentType.JSON);
		requestSpecification.header("x-zycus-tenantId", tenantId);
		requestSpecification.header("x-zycus-userId", Userid);
		requestSpecification.header("x-zycus-trackingNumber", trackingNumber);
		Response response = requestSpecification.get(URI);
		return response;
	}
	
	/***
	 * 
	 * @param URI
	 * @param Userid
	 * @param tenantId
	 * @return Response
	 */
	public static Response GETRequestWithHeader(String URI,String Userid,String tenantId) {
		RequestSpecification requestSpecification = RestAssured.given();
		requestSpecification.contentType(ContentType.JSON);
		requestSpecification.header("x-zycus-tenantId", tenantId);
		requestSpecification.header("x-zycus-userId", Userid);
		Response response = requestSpecification.get(URI);
		return response;
	}
	/***
	 * 
	 * @param URI
	 * @param Userid
	 * @param tenantId
	 * @param trackingNumber
	 * @return Responses
	 */
	
	public static Response DeleteRequestWithHeader(String URI,String Userid,String tenantId,int trackingNumber) {
		RequestSpecification requestSpecification = RestAssured.given();
		requestSpecification.contentType(ContentType.JSON);
		requestSpecification.header("x-zycus-tenantId", tenantId);
		requestSpecification.header("x-zycus-userId", Userid);
		requestSpecification.header("x-zycus-trackingNumber", trackingNumber);
		Response response = requestSpecification.delete(URI);
		return response;
	}
	

}
