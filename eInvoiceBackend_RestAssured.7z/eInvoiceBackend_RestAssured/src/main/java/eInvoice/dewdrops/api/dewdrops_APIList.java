package eInvoice.dewdrops.api;
/***
 * This class will contain all The API's of Dewdrops
 * @author ashiwani.ranjan
 *
 */

public final class dewdrops_APIList {
	
	public static final String filterAPI_Invoice="/einvoice/soa-services/restapi/invoice/filter";//EINVOICE-12147
	public static final String filterAPI_CreditMemo="/einvoice/soa-services/restapi/invoice/filter";//EINVOICE-12275
	public static final String Search_Attachement_Api="/einvoice/soa-services/restapi/attachment/filter";//EINVOICE-12277
	public static final String Get_Audittrail_Invoice_Api="/einvoice/soa-services/restapi/invoice/";//EINVOICE-12338
	public static final String Get_Audittrail_CreditMemo_Api="/einvoice/soa-services/restapi/creditMemo/";//EINVOICE-12356
	public static final String Get_Attachment_Api="/einvoice/soa-services/restapi/attachment/";//EINVOICE-12336
	public static final String searchRoleBasedUsers_Api="/einvoice/soa-services/restapi/user/filter/";//EINVOICE-12517
	public static final String searchUsers_Api="/einvoice/soa-services/restapi/user/filter";//EINVOICE-12518
	public static final String searchSupplier_Api="/einvoice/soa-services/restapi/user/filter";//EINVOICE-12278

	
	

}
