package eInvoice.dewdrops.test.sprint1;

import java.io.IOException;

import java.awt.geom.Arc2D.Double;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.http.Header;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import eInvoice.dewdrops.util.TestBase;
import eInvoice.dewdrops.util.TestUtil;
import eInvoice.dewdrops.util.Webservices;
import eInvoice.dewdrops.util.Xls_reader;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class testCreditMemoApportionment extends TestBase {
	TestBase testBase;
	Response response;

	protected String serviceUrl;
	protected String apiUrl;
	protected String tenantId;
	protected String TestData;
	protected String url;
	Xls_reader reader;

	@BeforeClass(alwaysRun = true)
	@Parameters({ "serviceUrl", "apiUrl", "tenantId", "TestData" })
	public void initialization(String testserviceUrl, String testapiUrl, String testtenantId, String testTestData) {

		serviceUrl = testserviceUrl;
		apiUrl = testapiUrl;
		tenantId = testtenantId;
		TestData = testTestData;

		reader = new Xls_reader(System.getProperty("user.dir") + "\\src\\main\\java\\eInvoice\\dewdrops\\testdata\\"
				+ TestData + ".xlsx");

	}

	@Test(priority = 1)
	public void postcreditmemo_Apportionment_Valid_Data() throws ClientProtocolException, IOException, JSONException {

		Integer RowNo = 2;
		String TestDataSheet = "CreditMemoApportionment";

		// Print the value
		Reporter.log("ServiceUrl 	: " + serviceUrl, true);
		Reporter.log("ApiUrl 		: " + apiUrl, true);
		Reporter.log("TenantId 	: " + tenantId, true);
		Reporter.log(" ");
		url = serviceUrl + apiUrl;
		Reporter.log("baseUrl  --> : " + url, true);
		Reporter.log(" ");

		String createProfileRespString;
		createProfileRespString = TestUtil.getTest_JSON();
		// System.out.println("payload --> : " + createProfileRespString);

		JSONObject existingPreferenceObject = new JSONObject(createProfileRespString);
		JSONObject jsonChildObject = (JSONObject) existingPreferenceObject.get("IntegrationEntities");

		// System.out.println("jsonChildObject --> : " + jsonChildObject);

		JSONArray result = jsonChildObject.getJSONArray("integrationEntity");
		// System.out.println("result --> : " + result);

		JSONObject result1 = result.getJSONObject(0);
		// System.out.println("result1 --> : " + result1);

		JSONObject result2 = (JSONObject) result1.get("integrationEntityDetails");
		// System.out.println("result2 --> : " + result2);

		JSONObject result3 = (JSONObject) result2.get("creditMemoApportionment");
		// System.out.println("result3 --> : " + result3);

		String creditMemoId = reader.getCellData(TestDataSheet, "creditMemoId", RowNo);
		String apportionedAmount = reader.getCellData(TestDataSheet, "apportionedAmount", RowNo);

		Reporter.log("creditMemoId  --> : " + creditMemoId, true);
		Reporter.log("apportionedAmount  --> : " + apportionedAmount, true);
		System.out.println(" ");

		// JSONObject milestone1 = new JSONObject();
		result3.put("creditMemoId", creditMemoId);
		result3.put("apportionedAmount", apportionedAmount);

		String finalJson = ((Object) existingPreferenceObject).toString();

		response = Webservices.Post(url, finalJson, tenantId);

		JSONObject responseResult = new JSONObject(response.asString());

		JSONObject responseResult1 = (JSONObject) responseResult.get("IntegrationEntities");
		// System.out.println("responseResult1 " +responseResult1);

		JSONArray responseResult2 = responseResult1.getJSONArray("integrationEntity");
		// System.out.println("responseResult2 " +responseResult2);

		JSONObject responseResult3 = responseResult2.getJSONObject(0);
		// System.out.println("responseResult3 " +responseResult3);

		JSONObject responseResult4 = (JSONObject) responseResult3.get("integrationEntityDetails");
		// System.out.println("responseResult4 " +responseResult4);

		JSONObject responseResult5 = (JSONObject) responseResult4.get("acknowledgement");
		// System.out.println("responseResult5 " +responseResult5);

		Reporter.log(" ", true);
		String responseResult_status = responseResult5.getString("status");
		System.out.println("responseResult_status -- > : " + responseResult_status);
		Reporter.log(" ", true);

		Assert.assertEquals(responseResult_status, "Passed", "Result is missmatch");

	}

	@Test(priority = 2)
	public void postcreditmemo_Apportionment_ALREADY_APPORTIONED()
			throws ClientProtocolException, IOException, JSONException {

		Integer RowNo = 2;
		String TestDataSheet = "CreditMemoApportionment";

		// Print the value
		Reporter.log("ServiceUrl 	: " + serviceUrl, true);
		Reporter.log("ApiUrl 		: " + apiUrl, true);
		Reporter.log("TenantId 	: " + tenantId, true);
		Reporter.log(" ");
		url = serviceUrl + apiUrl;
		Reporter.log("baseUrl  --> : " + url, true);
		Reporter.log(" ");

		String createProfileRespString;
		createProfileRespString = TestUtil.getTest_JSON();
		// System.out.println("payload --> : " + createProfileRespString);

		JSONObject existingPreferenceObject = new JSONObject(createProfileRespString);
		JSONObject jsonChildObject = (JSONObject) existingPreferenceObject.get("IntegrationEntities");

		// System.out.println("jsonChildObject --> : " + jsonChildObject);

		JSONArray result = jsonChildObject.getJSONArray("integrationEntity");
		// System.out.println("result --> : " + result);

		JSONObject result1 = result.getJSONObject(0);
		// System.out.println("result1 --> : " + result1);

		JSONObject result2 = (JSONObject) result1.get("integrationEntityDetails");
		// System.out.println("result2 --> : " + result2);

		JSONObject result3 = (JSONObject) result2.get("creditMemoApportionment");
		// System.out.println("result3 --> : " + result3);

		String creditMemoId = reader.getCellData(TestDataSheet, "creditMemoId", RowNo);
		String apportionedAmount = reader.getCellData(TestDataSheet, "apportionedAmount", RowNo);

		Reporter.log("creditMemoId  --> : " + creditMemoId, true);
		Reporter.log("apportionedAmount  --> : " + apportionedAmount, true);
		System.out.println(" ");

		// JSONObject milestone1 = new JSONObject();
		result3.put("creditMemoId", creditMemoId);
		result3.put("apportionedAmount", apportionedAmount);

		String finalJson = ((Object) existingPreferenceObject).toString();

		response = Webservices.Post(url, finalJson, tenantId);

		JSONObject responseResult = new JSONObject(response.asString());

		JSONObject responseResult1 = (JSONObject) responseResult.get("IntegrationEntities");
		// System.out.println("responseResult1 " +responseResult1);

		JSONArray responseResult2 = responseResult1.getJSONArray("integrationEntity");
		// System.out.println("responseResult2 " +responseResult2);

		JSONObject responseResult3 = responseResult2.getJSONObject(0);
		// System.out.println("responseResult3 " +responseResult3);

		JSONObject responseResult4 = (JSONObject) responseResult3.get("integrationEntityDetails");
		// System.out.println("responseResult4 " +responseResult4);

		JSONObject responseResult5 = (JSONObject) responseResult4.get("acknowledgement");
		// System.out.println("responseResult5 " +responseResult5);

		Reporter.log(" ");
		String responseResult_status = responseResult5.getString("status");
		Reporter.log("responseResult_status -- > : " + responseResult_status, true);
		Reporter.log(" ");

		if (responseResult_status.contains("FAILED")) {

			JSONObject responseResult6 = (JSONObject) responseResult3.get("processingErrors");
			System.out.println("responseResult6 " + responseResult6);

			JSONArray responseResult7 = responseResult6.getJSONArray("error");
			System.out.println("responseResult7 " + responseResult7);

			JSONObject responseResult8 = responseResult7.getJSONObject(0);
			System.out.println("responseResult8 " + responseResult8);

			String responseResult_errorDescription = responseResult8.getString("errorDescription");
			String responseResult_errorCode = responseResult8.getString("errorCode");

			System.out.println("responseResult_errorDescription " + responseResult_errorDescription);
			System.out.println("responseResult_errorCode " + responseResult_errorCode);

			Assert.assertEquals(responseResult_errorDescription, "Credit Memo is already fully apportioned.",
					"responseResult_errorDescription is missmatch");
			Assert.assertEquals(responseResult_errorCode, "ALREADY_APPORTIONED",
					"responseResult_errorCode is missmatch");

		} else {
			Assert.assertEquals(responseResult_status, "Passed", "Result is missmatch");
		}
	}

}
