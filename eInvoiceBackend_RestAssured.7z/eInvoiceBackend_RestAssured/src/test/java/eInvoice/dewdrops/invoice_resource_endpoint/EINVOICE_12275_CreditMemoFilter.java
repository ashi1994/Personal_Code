package eInvoice.dewdrops.invoice_resource_endpoint;

import org.testng.Reporter;
import org.testng.annotations.Test;

import eInvoice.dewdrops.api.dewdrops_APIList;
import eInvoice.dewdrops.util.TestBase;
import eInvoice.dewdrops.util.TestUtil;
import eInvoice.dewdrops.util.TestUtil;
import eInvoice.dewdrops.util.URL;
import eInvoice.dewdrops.util.Webservices;
import io.restassured.response.Response;

public class EINVOICE_12275_CreditMemoFilter  extends TestBase {
	@Test
	public void testCreditMemoFilter() throws Exception {
	  String userId=TestUtil.getUserid();
      String tenantid=TestUtil.getTenantid();
	  int trackingNumber=TestUtil.randomTrackingNumber();
	  String url=URL.getEndPoint(dewdrops_APIList.filterAPI_CreditMemo);
	  String createIssuePayLaod = TestUtil.generatePayLoadString("Filter_API_CreditMemo");
	  Response res=Webservices.POSTRequestWithHeader(url, createIssuePayLaod, userId, tenantid, trackingNumber);
	  Reporter.log("responseResult-> "+res.asString(),true);
	  Reporter.log("Error -"+res.jsonPath().get("processingErrors"),true);
	  
	  
	}

}
