package eInvoice.dewdrops.invoice_resource_endpoint;

import static org.testng.Assert.assertEquals;
import java.util.Arrays;

import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONString;
import org.testng.Reporter;
import org.testng.annotations.Test;

import eInvoice.dewdrops.api.dewdrops_APIList;
import eInvoice.dewdrops.util.TestUtil;
import eInvoice.dewdrops.util.TestBase;
import eInvoice.dewdrops.util.TestUtil;
import eInvoice.dewdrops.util.URL;
import eInvoice.dewdrops.util.Webservices;
import io.restassured.response.Response;

public class EINVOICE_12147_FilterAPI  extends TestBase{
	
//	@Test(priority=1)//,description="This test case verify filter api functionality with valid data")
	public void testFilterValidData() throws Exception {
      String userId=TestUtil.getUserid();
	  String tenantid=TestUtil.getTenantid();
	  int trackingNumber=TestUtil.randomTrackingNumber();
	  String url=URL.getEndPoint(dewdrops_APIList.filterAPI_Invoice);
	  String createIssuePayLaod = TestUtil.generatePayLoadString("Filter_API_Invoice");
	  Response res=Webservices.POSTRequestWithHeader(url, createIssuePayLaod, userId, tenantid, trackingNumber);
	 
	  // pls print the  response 
	 Reporter.log("Response "+res.asString(),true);	
	 //or
	  JSONObject responseResult = new JSONObject(res.asString());
	  Reporter.log("responseResult-> "+responseResult,true);
	  
	  Reporter.log("Error-> "+res.jsonPath().get("processingErrors"),true);
	  Reporter.log("Result found-> "+res.jsonPath().getList("result").size(),true);
	  assertEquals(res.getStatusCode(), TestUtil.RESPONSE_CODE_200);
	  // Json Value  should be  verified  not only response code
	  // retrived response is correct or not as per payload shd be validated
	  // ex : take one var : created on date : value shd be sorted or not
	}
	
//	@Test(priority=2)//,description="This test case verify filter api functionality with blank payload")
	public void testFilterInValidDataBlank() throws Exception {
      String userId=TestUtil.getUserid();
	  String tenantid=TestUtil.getTenantid();
	  int trackingNumber=TestUtil.randomTrackingNumber();
	  String url=URL.getEndPoint(dewdrops_APIList.filterAPI_Invoice);
	  String createIssuePayLaod = " ";
	  Response res=Webservices.POSTRequestWithHeader(url, createIssuePayLaod, userId, tenantid, trackingNumber);
	  Reporter.log("Error-> "+res.getStatusCode(),true);
	  assertEquals(res.getStatusCode(),	 TestUtil.RESPONSE_CODE_400);
	  // invlaid we cant send blank payload we can send invalid date not as payload
	}

//	@Test(priority=3)//,description="This test case verify filter api functionality with wrong userid and tenantid")
	public void testFilterInValidData() throws Exception {
      String userId="Invalid";
	  String tenantid="Invalid";
	  String url=URL.getEndPoint(dewdrops_APIList.filterAPI_Invoice);
	  String createIssuePayLaod = TestUtil.generatePayLoadString("Filter_API_Invoice");
	  Response res=Webservices.POSTRequestWithHeader(url, createIssuePayLaod, userId, tenantid);
	  Reporter.log("Error-> "+res.getStatusCode(),true);
	  assertEquals(res.jsonPath().get("errors.errorCode"), Arrays.asList(TestUtil.Invalid_User),"error");
	  // its invalid testcase not related to this functionalty coverage - its beging level as chking login case
	}
	
//	@Test(priority=4)//,description="This test case verify filter api functionality with different direction like(asc,desc)")
//	public void testFilterASC() throws Exception {
//      String userId=TestUtil.getUserid();
//	  String tenantid=TestUtil.getTenantid();
//	  String url=URL.getEndPoint(dewdrops_APIList.filterAPI_Invoice);
//	  String direction=reader.getCellData("FilterApi", "direction",3 );
//	  String createIssuePayLaod = TestUtil.generatePayLoadString("Filter_API_Invoice");
//      JSONObject pare=new JSONObject(createIssuePayLaod);
//      JSONArray jss=pare.getJSONArray("sortConditions");
//      System.out.println(jss);
//      JSONObject js=jss.getJSONObject(0);
//      Object result2 = js.get("direction");
//      Response res=Webservices.POSTRequestWithHeader(url, createIssuePayLaod, userId, tenantid);
//      assertEquals(res.getStatusCode(), TestUtil.RESPONSE_CODE_200);
//      // where is the order getting changed   here asc/dec  ?
//   
//	}
	
	//@Test(priority=5)//,description="This test case verify filter api functionality with different direction like(asc,desc)")
	public void testFilterDEC() throws Exception {
      String userId=TestUtil.getUserid();
	  String tenantid=TestUtil.getTenantid();
	  String url=URL.getEndPoint(dewdrops_APIList.filterAPI_Invoice);
	  String trackingNumber=reader.getCellData("FilterApi", "trackingNumber",2 );
	  String createIssuePayLaod = TestUtil.generatePayLoadString("Filter_API_Invoice");
      JSONObject pare=new JSONObject(createIssuePayLaod);
      JSONObject js=pare.getJSONObject("trackingNumber");
      System.out.println(js);
      // where post call ?  
	}
	
}
