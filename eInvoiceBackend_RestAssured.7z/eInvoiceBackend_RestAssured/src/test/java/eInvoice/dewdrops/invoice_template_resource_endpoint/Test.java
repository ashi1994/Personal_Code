package eInvoice.dewdrops.invoice_template_resource_endpoint;

public class Test {

}
